﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
[Serializable]
public class Chap
{
    public string slno { get; set; }
    public string ChapterName { get; set; }
    public string CENo_page { get; set; }
    public string CETimetaken { get; set; }
    public string No_page { get; set; }
    public string Timetaken { get; set; }
    public string IS { get; set; }
    public string IM { get; set; }
    public string IC { get; set; }
    public string IMC { get; set; }
    public string TS { get; set; }
    public string TM { get; set; }
    public string TC { get; set; }
    public string TMC { get; set; }
    public string ICS { get; set; }
    public string IE { get; set; }
    public string Blank { get; set; }
    public string Half { get; set; }
    public string Remaining { get; set; }
    public string ImgTimetaken { get; set; }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Security.Cryptography;
namespace ProductionCalculationClass
{
    interface UserInputs
    {
        int qid { get; set; }
        string comments { get; set; }
    }
}
/// <summary>
/// Summary description for LpzProduction Calculation
/// </summary>
public class ProductionCalculation
{
    clsDataControl objData = new clsDataControl();
    public static class PMSConstants
    {
        public const int TraineeQuantitative = 80;
        public const int TraineeQualitative = 20;

        public const int OLevelQuantitative = 80;
        public const int OLevelQualitative = 20;

        public const int ExeQuantitative = 60;
        public const int ExeQualitative = 40;

        public const int ManagerQuantitative = 40;
        public const int ManagerQualitative = 60;
    }
    /// <summary>
    /// Used For MonthWise Production Report
    /// </summary>
    /// <param name="grade"></param>
    /// <returns></returns>
    public List<string> getMonthWiseProduction(string FromDate, string ToDate, string EmpNo = "", bool isTL = false, string TLUserID = "")
    {
        List<string> Production = new List<string>();
        string OnTimeDelivery = string.Empty;
        string OnBeforeDelivery = string.Empty;
        string OnExtendDelivery = string.Empty;
        string AverageProduction = string.Empty;
        DateTime FromDateConverted = DateTime.ParseExact(FromDate, "dd/MM/yyyy", null);
        DateTime ToDateConverted = DateTime.ParseExact(ToDate, "dd/MM/yyyy", null);
        if (EmpNo != "N/A")
        {
            OnTimeDelivery = objData.GetSingleData("select count(id) as count from tbl_Taskmaster where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and Production='100' and userid='" + EmpNo + "'");
            OnBeforeDelivery = objData.GetSingleData("select count(id) as count from tbl_Taskmaster where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and Production>'100' and userid='" + EmpNo + "'");
            OnExtendDelivery = objData.GetSingleData("select count(id) as count from tbl_Taskmaster where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and Production<'100' and userid='" + EmpNo + "'");
            AverageProduction = objData.GetSingleData("select AVG(Production) as ProductionAverage from tbl_Taskmaster where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and userid='" + EmpNo + "'");
            if (AverageProduction == "")
                AverageProduction = "0";
        }
        else
        {
            OnTimeDelivery = objData.GetSingleData("select count(id) as count from tbl_Taskmaster where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and Production='100' and userid!='L1040'");
            OnBeforeDelivery = objData.GetSingleData("select count(id) as count from tbl_Taskmaster where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and Production>'100' and userid!='L1040'");
            OnExtendDelivery = objData.GetSingleData("select count(id) as count from tbl_Taskmaster where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and Production<'100' and userid!='L1040'");
            AverageProduction = objData.GetSingleData("select AVG(Production) as ProductionAverage from tbl_Taskmaster where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and userid!='L1040'");
            if (AverageProduction == "")
                AverageProduction = "0";
            if (isTL)
            {
                string TeamUsers = objData.GetSingleData("select replace(''''+userid+'''',',',''',''') as Users from tbl_TeamAllotmentMaster where TeamLeader='" + TLUserID + "'");
                OnTimeDelivery = objData.GetSingleData("select count(id) as count from tbl_Taskmaster where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and Production='100' and userid in (" + TeamUsers + ")");
                OnBeforeDelivery = objData.GetSingleData("select count(id) as count from tbl_Taskmaster where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and Production>'100' and userid in (" + TeamUsers + ")");
                OnExtendDelivery = objData.GetSingleData("select count(id) as count from tbl_Taskmaster where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and Production<'100' and userid in (" + TeamUsers + ")");
                AverageProduction = objData.GetSingleData("select AVG(Production) as ProductionAverage from tbl_Taskmaster where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and userid in (" + TeamUsers + ")");
				if (AverageProduction == "")
					AverageProduction = "0";
            }
        }
        Production.Add(OnBeforeDelivery);
        Production.Add(OnTimeDelivery);
        Production.Add(OnExtendDelivery);
        Production.Add(AverageProduction);
        return Production;
    }
    /// <summary>
    /// Used For MonthWise Production Report
    /// </summary>
    /// <param name="grade"></param>
    /// <returns></returns>
	public int getProductionOfTask(int TaskID, string TotalTime,bool OnUpdate=false,string DprId="")
    {
        int ProductionValue = 0;
        double ProductionCalc;
        int EstimatedTime = Convert.ToInt32(objData.GetSingleData("select Left(estimatedtime,3)*60+right(estimatedtime,2) from tbl_Taskmaster where estimatedtime is not null and estimatedtime is not null and estimatedtime!='___:__' and estimatedtime!='__:__' and id='" + TaskID + "'"));
        if (EstimatedTime != 0)
        {
            int DoneTime = Convert.ToInt32(objData.GetSingleData("select ISNULL(SUM(DATEDIFF(MINUTE,'00:00:00', TotalTime)),0) from PrmsProductionHour_Backup where task='" + TaskID + "'"));
            int CurrentTime = Convert.ToInt32(TotalTime.Substring(0, 2)) * 60 + Convert.ToInt32(TotalTime.Substring(3, 2));
            if (!OnUpdate)
            {
                DoneTime += CurrentTime;
            }
            else
            { 
                DoneTime = Convert.ToInt32(objData.GetSingleData("select ISNULL(SUM(DATEDIFF(MINUTE,'00:00:00', TotalTime)),0) from PrmsProductionHour_Backup where slno!='" + DprId + "' and task='"+TaskID+"'"));
                DoneTime += CurrentTime;
            }
            ProductionCalc = (Convert.ToDouble(EstimatedTime) / Convert.ToDouble(DoneTime)) * 100;
            ProductionValue = Convert.ToInt32(ProductionCalc);
            if (ProductionValue >= 140)
                ProductionValue = 140;
            else if (ProductionValue < 1)
                ProductionValue = 0;
        }
        else
        {
            ProductionValue = -5;
        }
        return ProductionValue;
    }
    public string generateBarChart(string EmpNo, string FromDate, string ToDate, bool isTL = false, string TL_ID = "")
    {
        DateTime FromDateConverted;
        DateTime ToDateConverted;
        DataTable dt = null;
        StringBuilder sb = new StringBuilder();
        string jsonString = string.Empty;
        FromDateConverted = DateTime.ParseExact(FromDate, "dd/MM/yyyy", null);
        ToDateConverted = DateTime.ParseExact(ToDate, "dd/MM/yyyy", null);
        sb.Append("[");
        if (EmpNo == "N/A")
        {
            dt = objData.Getdata("select a.userid,b.username,AVG(a.Production) from tbl_taskmaster a inner join tbl_usermaster b on a.userid=b.userid where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and b.status=1 and a.taskstatus='Completed' group by a.userid,b.username");
            if (isTL)
            {
                string TeamUsers = objData.GetSingleData("select replace(''''+userid+'''',',',''',''') as Users from tbl_TeamAllotmentMaster where TeamLeader='" + TL_ID + "'");
                dt = objData.Getdata("select a.userid,b.username,AVG(a.Production) from tbl_taskmaster a inner join tbl_usermaster b on a.userid=b.userid where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and b.status=1 and a.taskstatus='Completed' and a.userid in (" + TeamUsers + ") group by a.userid,b.username");
            }
        }
        else
        {
            if (FromDateConverted.Month == ToDateConverted.Month)
            {
                dt = objData.Getdata("select requireddate,Convert(varchar(11),Requireddate,106) as Date,Avg(Production) as ProductionRate from tbl_taskmaster where taskstatus='Completed' and userid='" + EmpNo + "' and requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' group by Requireddate order by requireddate");
            }
            else
            {
                dt = objData.Getdata("select month(requireddate),datename(month,Requireddate)+' : '+convert(varchar(5),year(Requireddate)) as Month,Avg(Production) as ProductionRate from tbl_taskmaster where taskstatus='Completed' and userid='" + EmpNo + "' and requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' group by datename(month,Requireddate),year(requireddate),month(requireddate) order by year(requireddate),month(requireddate)");
                //dt = objData.Getdata("select month(requireddate),datename(month,Requireddate) as Month,Avg(Production) as ProductionRate from tbl_taskmaster where taskstatus='Completed' and userid='" + EmpNo + "' and requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' group by datename(month,Requireddate),month(requireddate) order by month(requireddate)"); 
                if (isTL)
                {
                    string TeamUsers = objData.GetSingleData("select replace(''''+userid+'''',',',''',''') as Users from tbl_TeamAllotmentMaster where TeamLeader='" + TL_ID + "'");
                    dt = objData.Getdata("select a.userid,b.username,AVG(a.Production) from tbl_taskmaster a inner join tbl_usermaster b on a.userid=b.userid where requireddate between '" + FromDateConverted + "' and '" + ToDateConverted + "' and b.status=1 and a.taskstatus='Completed' and a.userid in (" + TeamUsers + ") group by a.userid,b.username");
                }
            }
        }
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                sb.Append("{");
                sb.Append("\"country\" : ");
                sb.Append("\"" + dt.Rows[i][1].ToString() + "\",");
                sb.Append("\"visits\" : ");
                sb.Append(dt.Rows[i][2].ToString());
                sb.Append("},");
            }
            sb.Length--;
            sb.Append("]");
        }
        jsonString = sb.ToString();
        if (jsonString == "[")
            jsonString = "0";
        return jsonString;
    }
	/// <summary>
	/// Generic Method To Generate Excel Report
	/// </summary>
	/// <returns>The excel report.</returns>
	/// <param name="dt">Dt.</param>
	/// <param name="filename">Filename.</param>
	/// <param name="FolderPath">Folder path.</param>
	/// <param name="ReportName">Report name.</param>
	/// <param name="NoOfColumns">No of columns.</param>
	/// <param name="headernames">Headernames.</param>
	public List<string> generateExcelReport(DataTable dt, string filename, string FolderPath,string ReportName,int NoOfColumns,List<string> headernames)
	{
		List<string> ToGenerate=new List<string>();
		string filePath = HttpContext.Current.Server.MapPath(".") + "\\"+FolderPath+"\\";
		if (!Directory.Exists(filePath))
			Directory.CreateDirectory(filePath + "\\"+FolderPath+"\\");
		string excelpath = filePath + (filename + DateTime.Now.ToShortDateString().Replace("/", "") + ".xls");
		if (File.Exists(excelpath))
			File.Delete(excelpath);
		FileInfo file = new FileInfo(excelpath);
		string reportName = ReportName+" as on : " + DateTime.Now.ToString("dd/MM/yyyy");
		StringBuilder sb = new StringBuilder();
		sb.Append("<html>");
		sb.Append("<head>");
		sb.Append("<body>");
		sb.Append("<table border='1' style='font-family:Calibri; font-size:14px;'>");
		sb.Append("<tr><td colspan='"+NoOfColumns+"' style='text-align:center;vertical-align:middle;font-weight:bold;background-color: #ddebf7;'>" + reportName + "</td></tr>");
		sb.Append("<tr>");
		foreach(string header in headernames)
		{
			sb.Append("<td style='text-align:center;vertical-align:middle;font-weight:bold;background-color: #ddebf7;'>"+header+"</td>");
		}
		sb.Append("</tr>");
		foreach(DataRow row in dt.Rows)
		{
			sb.Append("<tr>");
			foreach(DataColumn column in dt.Columns)
			{
				sb.Append("<td style='text-align:center;vertical-align:middle;'>" + row[column].ToString().ToUpper().Replace("__:__","NA") + "</td>");
			}
			sb.Append("</tr>");
		}
		sb.Append("</table>");
		sb.Append("</body>");
		sb.Append("</head>");
		sb.Append("</html>");
		File.WriteAllText(excelpath, sb.ToString());
		ToGenerate.Add (filePath.ToString());
		ToGenerate.Add (file.ToString());
		ToGenerate.Add (excelpath.ToString());
		return ToGenerate;
	}
}

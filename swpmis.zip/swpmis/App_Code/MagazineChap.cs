﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
[Serializable]
public class MagazineChap
{
    public string slno { get; set; }
    public string ChapterName { get; set; }
    public string MSSNo_Page { get; set; }
    public string MSSTimetaken { get; set; }
    public string OPNo_Page { get; set; }
    public string OPTimetaken { get; set; }
    public string REFNo_Page { get; set; }
    public string REFTimetaken { get; set; }
    public string No_CPage { get; set; }
    public string No_PPage { get; set; }
    public string PTimetaken { get; set; }
    public string TENo_Page { get; set; }
    public string TETimetaken { get; set; }
    public string TENo_table { get; set; }
    public string TEtableTimetaken { get; set; }
    public string TMNo_Page { get; set; }
    public string TMTimetaken { get; set; }
    public string TMNo_Table { get; set; }
    public string TMtableTimetaken { get; set; }
    public string FRSNo_Page { get; set; }
    public string FRSTimetaken { get; set; }
    public string FRMNo_Page { get; set; }
    public string FRMTimetaken { get; set; }
    public string FRCNo_Page { get; set; }
    public string FRCTimetaken { get; set; }
    public string FRCSNo_Page { get; set; }
    public string FRCSTimetaken { get; set; }
    public string FRCMNo_Page { get; set; }
    public string FRCMTimetaken { get; set; }
    public string FRCCNo_Page { get; set; }
    public string FRCCTimetaken { get; set; }
    public string Blank { get; set; }
}

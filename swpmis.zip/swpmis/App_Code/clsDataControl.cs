﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Web;
using System.IO;
using System.Web.UI;
using System.Net;

[Serializable]
public class clsDataControl
{
    public clsDataControl()
    {
        DynamicParameters = new Dictionary<string, object>();
    }

    public string con = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
    public SqlCommand comm = new SqlCommand();
    public Dictionary<string, object> DynamicParameters { get; set; }
    public DataTable Getdata(string sqlstr)
    {
        SqlDataAdapter da = new SqlDataAdapter(sqlstr, con);
        DataTable dt = new DataTable();
        da.SelectCommand.CommandTimeout = 60;
        da.Fill(dt);
        return dt;
    }
    public bool DataExeuteScalar(string sqlstr)
    {
        using (SqlConnection connection = new SqlConnection(con))
        {
            comm.Connection = connection;
            comm.CommandText = sqlstr;
            connection.Open();
            comm.ExecuteScalar();
            connection.Close();
        }
        return true;
    }
    public string GetSingleData(string sqlstr)
    {
        SqlDataAdapter da = new SqlDataAdapter(sqlstr, con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
            return dt.Rows[0][0].ToString();
        else
            return "0";
    }

    public bool DataAuthendication(string sqlstr)
    {
        SqlDataAdapter da = new SqlDataAdapter(sqlstr, con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
            return true;
        else
            return false;
    }
    public bool DataExecute(string sqlstr)
    {
        using (SqlConnection connection = new SqlConnection(con))
        {
            comm.Connection = connection;
            comm.CommandText = sqlstr;
            connection.Open();
            comm.ExecuteNonQuery();
            connection.Close();
        }
        return true;
    }

    public bool InsertOrUpdateData(string argstrQuery, Boolean IsSp = false, Boolean IsParameter = false)
    {
        Boolean IsSaved = false;
        using (SqlConnection connection = new SqlConnection(con))
        {
            try
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = argstrQuery;
                if (IsSp)
                    cmd.CommandType = CommandType.StoredProcedure;
                else
                    cmd.CommandType = CommandType.Text;
                if (IsParameter)
                {
                    if (DynamicParameters.Count > 0)
                    {
                        foreach (KeyValuePair<string, object> item in DynamicParameters)
                            cmd.Parameters.AddWithValue(item.Key, item.Value);
                        int i = cmd.ExecuteNonQuery();
                        if (i != 0)
                            IsSaved = true;
                    }
                }
                else
                {
                    int i = cmd.ExecuteNonQuery();
                    if (i != 0)
                        IsSaved = true;
                }
            }
            catch (SqlException)
            {
                if (connection != null) ((IDisposable)connection).Dispose();
            }
        }
        return IsSaved;
    }

    public DataTable GetDetails(string argstrQuery, Boolean IsSp = false, Boolean IsParameter = false, Boolean isCombo = false, string argstrIntialValue = "--Select--")
    {
        DataTable dtData = null;
        using (SqlConnection connection = new SqlConnection(con))
        {
            try
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = argstrQuery;
                cmd.Connection = connection;
                if (IsSp)
                {
                    if (IsParameter)
                    {
                        if (DynamicParameters.Count > 0)
                        {
                            foreach (KeyValuePair<string, object> item in DynamicParameters)
                                cmd.Parameters.AddWithValue(item.Key, item.Value);
                        }
                    }
                    cmd.CommandType = CommandType.StoredProcedure;
                }
                else
                    cmd.CommandType = CommandType.Text;
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dtData = new DataTable();
                    dtData.Load(dr);
                    if (isCombo)
                    {
                        DataRow drs = dtData.NewRow();
                        drs[0] = "0";
                        drs[1] = argstrIntialValue;
                        dtData.Rows.InsertAt(drs, 0);
                    }
                }
            }
            catch (SqlException)
            {
                if (connection != null)
                    ((IDisposable)connection).Dispose();
            }
        }
        return dtData;
    }

    public void excelReport(DataTable dt)
    {
        try
        {
            string filePath = HttpContext.Current.Server.MapPath(".") + "\\Reports\\";
            if (!Directory.Exists(filePath))
                Directory.CreateDirectory(filePath + "\\Reports\\");
            string excelpath = filePath + "\\" + ("Reports" + ".xls");
            if (File.Exists(excelpath))
                File.Delete(excelpath);

            FileInfo file = new FileInfo(excelpath);
            StreamWriter writter = new StreamWriter(excelpath, true);
            writter.WriteLine("<html>");
            writter.WriteLine("<head>");
            writter.WriteLine("<body>");
            writter.WriteLine("<table border='1'><tr>");
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                writter.WriteLine("<td> <b>" + dt.Columns[i].ToString().ToUpper() + "</b></td>");

            }
            writter.WriteLine("</tr>");
            for (int i1 = 0; i1 < dt.Rows.Count; i1++)
            {
                writter.WriteLine("<tr>");
                for (int i2 = 0; i2 < dt.Columns.Count; i2++)
                    writter.WriteLine("<td >" + dt.Rows[i1][i2].ToString().ToUpper() + "</td>");
                writter.WriteLine("</tr>");
            }
            writter.WriteLine("</table>");
            writter.WriteLine("</body>");
            writter.WriteLine("</head>");
            writter.WriteLine("</html>");
            writter.Close();
            HttpContext.Current.Response.ContentType = "application/ms-excel";
            HttpContext.Current.Response.AddHeader("content-disposition", "inline; filename=Records.xls");
            HttpContext.Current.Response.TransmitFile(excelpath);
            HttpContext.Current.Response.Flush();
        }
        catch (Exception e)
        { }
    }
    public string getJSON(DataTable dt)
    {
        System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row;
        foreach (DataRow dr in dt.Rows)
        {
            row = new Dictionary<string, object>();
            foreach (DataColumn col in dt.Columns)
                row.Add(col.ColumnName, dr[col]);
            rows.Add(row);
        }
        return serializer.Serialize(rows);
    }
    public string GetCurrenttime()
    {
        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
        {
            SqlCommand cmd = new SqlCommand("select SUBSTRING(a,12,5) from(select CONVERT(varchar(22), GETDATE(),120)a)a", con);
            con.Open();
            string ReturnValue = Convert.ToString(cmd.ExecuteScalar());
            return ReturnValue;
        }
    }

    public string GetCurrentDateTime()
    {
        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
        {
            SqlCommand cmd = new SqlCommand("select CONVERT(varchar,GETDATE(),103)+' '+LEFT(CONVERT(varchar,GETDATE(),108),5)", con);
            con.Open();
            string ReturnValue = Convert.ToString(cmd.ExecuteScalar());
            return ReturnValue;
        }
    }

    public string Subtract(string Start, string End, string Break, string Extra)
    {
		if (Start.Contains ('_') || End.Contains ('_')) 
		{
			return "";
		}
		else
		{
			DateTime t1 = DateTime.ParseExact(Start, "dd/MM/yyyy HH:mm", null);
			DateTime t11 = DateTime.ParseExact(End, "dd/MM/yyyy HH:mm", null);
			TimeSpan t2;
			if (t1 < t11)
			{
				t2 = DateTime.ParseExact(End, "dd/MM/yyyy HH:mm", null).Subtract(t1);
			}
			else
			{
				var result = TimeSpan.Parse("23:00:00");
				var result2 = TimeSpan.Parse("01:00:00");
				TimeSpan t3 = DateTime.ParseExact(Start, "dd/MM/yyyy HH:mm", null).Subtract(t11);
				TimeSpan t4 = new TimeSpan(Convert.ToInt32(t3.ToString().Split(':')[0]), Convert.ToInt32(t3.ToString().Split(':')[1]), Convert.ToInt32(t3.ToString().Split(':')[2]));
				TimeSpan t5 = new TimeSpan(Convert.ToInt32(result.ToString().Split(':')[0]), Convert.ToInt32(result.ToString().Split(':')[1]), Convert.ToInt32(result.ToString().Split(':')[2])).Add(result2);
				t2 = t5.Subtract(t4);
				//t2 = new TimeSpan(Convert.ToInt32(t3.ToString().Split(':')[0]), Convert.ToInt32(t3.ToString().Split(':')[1]), Convert.ToInt32(t3.ToString().Split(':')[2]));
			}
			TimeSpan T3 = new TimeSpan(0, Convert.ToInt32(Break), 0);
			TimeSpan T4 = new TimeSpan(Convert.ToInt32(Extra.ToString().Split(':')[0]), Convert.ToInt32(Extra.ToString().Split(':')[1]), 0);
			var TotalMinite = ((t2.Subtract(T3)).Subtract(T4)).TotalMinutes;
			string TotalTime = String.Format("{0:00}", Convert.ToDouble((TotalMinite / 60).ToString().Split('.')[0])) + ":" + string.Format("{0:00}", Convert.ToDouble((TotalMinite % 60).ToString().Split('.')[0]));
			return TotalTime;
		}
    }
    public string SubtractNew(string Start, string End, string Break, string Extra)
    {
        DateTime t1 = DateTime.ParseExact(Start, "dd/MM/yyyy HH:mm", null);
        TimeSpan t2 = DateTime.ParseExact(End, "dd/MM/yyyy HH:mm", null).Subtract(t1);

        TimeSpan T3 = new TimeSpan(0, Convert.ToInt32(Break), 0);
        TimeSpan T4 = new TimeSpan(Convert.ToInt32(Extra.ToString().Split(':')[0]), Convert.ToInt32(Extra.ToString().Split(':')[1]), 0);
        if (Extra != "__:__" && Extra != "")
        {
            T4 = new TimeSpan(Convert.ToInt32(Extra.ToString().Split(':')[0]), Convert.ToInt32(Extra.ToString().Split(':')[1]), 0);
        }
        var TotalMinite = ((t2.Subtract(T3)).Subtract(T4)).TotalMinutes;
        string TotalTime = String.Format("{0:00}", Convert.ToDouble((TotalMinite / 60).ToString().Split('.')[0])) + ":" + string.Format("{0:00}", Convert.ToDouble((TotalMinite % 60).ToString().Split('.')[0]));
        return TotalTime;
    }
    public string SubtractMin(string Start, string End, string Break, string Extra)
    {
        DateTime t1 = DateTime.ParseExact(Start, "dd/MM/yyyy HH:mm", null);
        TimeSpan t2 = DateTime.ParseExact(End, "dd/MM/yyyy HH:mm", null).Subtract(t1);

        TimeSpan T3 = new TimeSpan(0, Convert.ToInt32(Break), 0);
        TimeSpan T4 = new TimeSpan(Convert.ToInt32(Extra.ToString().Split(':')[0]), Convert.ToInt32(Extra.ToString().Split(':')[1]), 0);
        var TotalMinite = ((t2.Subtract(T3)).Subtract(T4)).TotalMinutes;
        //string TotalTime = String.Format("{0:00}", Convert.ToDouble((TotalMinite / 60).ToString().Split('.')[0])) + ":" + string.Format("{0:00}", Convert.ToDouble((TotalMinite % 60).ToString().Split('.')[0]));
        return Convert.ToString(TotalMinite);
    }

    public string getSlnoGeneration(string ProjectID, string Department, string Type, string filename)
    {
        try
        {
            int DCNo = 0;
            using (SqlConnection dcscon = new SqlConnection(ConfigurationManager.ConnectionStrings["DCSconn"].ConnectionString))
            {
                if (dcscon.State == ConnectionState.Closed) dcscon.Open();
                SqlCommand cmd = new SqlCommand("Sp_DcsOnlinetest", dcscon);
                cmd.Parameters.Clear();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SelectedMonth", Convert.ToString(System.DateTime.Now.ToString("MM")));
                cmd.Parameters.AddWithValue("@CurDate", Convert.ToString(DateTime.Now.ToString("MM/dd/yyyy hh:mm tt")));
                cmd.Parameters.AddWithValue("@DcsDate", Convert.ToString(System.DateTime.Now.ToString("MM/dd/yyyy")));
                cmd.Parameters.AddWithValue("@ProjectID", ProjectID);
                cmd.Parameters.AddWithValue("@Department", Department.ToUpper());
                cmd.Parameters.AddWithValue("@LOLorLDS", Type);
                cmd.Parameters.AddWithValue("@IP", Convert.ToString(System.Environment.UserDomainName) + "^" + Convert.ToString(System.Environment.UserName) + "^" + Convert.ToString(Dns.GetHostName()) + "^" + Convert.ToString(Dns.GetHostEntry(Dns.GetHostName()).AddressList[0]));
                cmd.Parameters.AddWithValue("@Filename", Convert.ToString(filename));

                SqlParameter DcsNO = new SqlParameter();
                DcsNO.Direction = ParameterDirection.Output;
                DcsNO.SqlDbType = SqlDbType.BigInt;
                DcsNO.ParameterName = "DcsNO";
                cmd.Parameters.Add(@DcsNO);
                cmd.ExecuteNonQuery();
                DCNo = Convert.ToInt32(DcsNO.Value);

            }
            string DCSAutono = DCNo.ToString("0000") + " - " + DateTime.Now.ToString("MM") + " - " + DateTime.Now.ToString("yy") + " - T - " + Convert.ToString(Type);
            return DCSAutono;
        }
        catch (Exception e)
        {
            return "Error-" + e.ToString();
        }
    }
}
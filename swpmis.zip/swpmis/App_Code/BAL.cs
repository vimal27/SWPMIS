using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
//using System.DirectoryServices;

[Serializable]
public class BAL
{
    SqlConnection con;
    SqlDataAdapter sda=new SqlDataAdapter();
    SqlCommand cmd=new SqlCommand();
    DataTable dts = new DataTable();
    public Dictionary<string, object> DParameter { get; set; }
    string Result = string.Empty;
    public BAL() { DParameter = new Dictionary<string, object>(); }
    #region Clear Member Function
    public void Clear_DropDownList(ControlCollection ControlCollections)
    {
        List<DropDownList> allControls = new List<DropDownList>();
        GetControlList<DropDownList>(ControlCollections, allControls);
        foreach (var childControl in allControls) { childControl.SelectedIndex = -1; }
    }
    public void Clear_TextBox(ControlCollection ControlCollections)
    {
        List<TextBox> allControls1 = new List<TextBox>();
        GetControlList<TextBox>(ControlCollections, allControls1);
        foreach (var childControl in allControls1) { childControl.Text = ""; }
    }
    public void Clear_RadioButtonList(ControlCollection ControlCollections)
    {
        List<RadioButtonList> allControls2 = new List<RadioButtonList>();
        //GetControlList<RadioButtonList>(Page.Controls, allControls2);
        GetControlList<RadioButtonList>(ControlCollections, allControls2);
        foreach (var childControl in allControls2) { childControl.SelectedIndex = -1; }
    }
    public void Clear_CheckBoxList(ControlCollection ControlCollections)
    {
        List<CheckBoxList> allControls3 = new List<CheckBoxList>();
        GetControlList<CheckBoxList>(ControlCollections, allControls3);
        foreach (var childControl in allControls3) { childControl.SelectedIndex = -1; }
    }
    private void GetControlList<T>(ControlCollection controlCollection, List<T> resultCollection) where T : Control
    {
        foreach (Control control in controlCollection)
        {
            //if (control.GetType() == typeof(T))
            if (control is T) // This is cleaner
                resultCollection.Add((T)control);

            if (control.HasControls())
                GetControlList(control.Controls, resultCollection);
        }
    }
    #endregion

    #region SQLCommand Member Function
    public string CAIUDT_Data(string ConnectionName, string Query, CommandType CommandTypes = CommandType.Text, Boolean IsParam = false)
    {
        try
        {
            using (con = new SqlConnection(ConfigurationManager.ConnectionStrings[ConnectionName].ConnectionString))
            {
                cmd.Parameters.Clear();
                cmd.Connection = con;
                cmd.CommandText = Query;
                cmd.CommandType = CommandTypes;
                if (IsParam)
                {
                    foreach (KeyValuePair<string, object> kvp in DParameter)
                        cmd.Parameters.AddWithValue(kvp.Key, kvp.Value);
                }
                if (con.State == ConnectionState.Closed) con.Open();
                Result = Convert.ToString(cmd.ExecuteNonQuery());
                //if (Result == "1") Result = Result + " row affected";
                //else Result = Result + " row(s) affected";
            }
        }
        catch (Exception Ex) { Result = Ex.Message; }
        finally
        {
            cmd.Dispose();
            if (con.State == ConnectionState.Open) con.Close();
        }
        return Result;
    }
    #endregion

    #region SQLDataAdapter Member Function
    public string SingleData(string ConnectionName, string Query, CommandType CommandTypes = CommandType.Text, Boolean IsParam = false)
    {
        try
        {
            using (con = new SqlConnection(ConfigurationManager.ConnectionStrings[ConnectionName].ConnectionString))
            {
                cmd.Parameters.Clear();
                cmd.Connection = con;
                cmd.CommandText = Query;
                cmd.CommandType = CommandTypes;
                if (IsParam)
                {
                    foreach (KeyValuePair<string, object> kvp in DParameter)
                        cmd.Parameters.AddWithValue(kvp.Key, kvp.Value);
                }
                if (con.State == ConnectionState.Closed) con.Open();
                Result = Convert.ToString(cmd.ExecuteScalar());
            }
        }
        catch (Exception Ex)
        {
            Result = Ex.Message;
        }
        finally
        {
            cmd.Dispose();
            sda.Dispose();            
        }
        return Result;
    }
    public DataTable SelectMethod(string ConnectionName, string Query, CommandType CommandTypes = CommandType.Text, Boolean IsParam = false)
    {
        try
        {
            using (con = new SqlConnection(ConfigurationManager.ConnectionStrings[ConnectionName].ConnectionString))
            {
                cmd.Parameters.Clear();
                dts.Clear();
                cmd.Connection = con;
                cmd.CommandText = Query;
                cmd.CommandType = CommandTypes;
                if (IsParam)
                {
                    foreach (KeyValuePair<string, object> kvp in DParameter)
                        cmd.Parameters.AddWithValue(kvp.Key, kvp.Value);
                }
                if (con.State == ConnectionState.Closed) con.Open();
                sda = new SqlDataAdapter(cmd);
                sda.Fill(dts);
            }
        }
        catch (Exception Ex) { dts = null; }
        finally
        {
            cmd.Dispose();
            sda.Dispose();            
        }
        return dts;
    }
    public void FillData(System.Web.UI.WebControls.WebControl ctrl, DataTable dt, Boolean IsSelectValue = false, string DataTextField = null, string DataValueField = null, string SelectText = "-select-")
    {
        try
        {
            if (ctrl.GetType() == typeof(System.Web.UI.WebControls.DropDownList))
            {
                DropDownList ddls = (DropDownList)ctrl;                
                ddls.DataSource = dt;
                ddls.DataTextField = DataTextField;
                ddls.DataValueField = DataValueField;
                ddls.DataBind();
                if (IsSelectValue) { ddls.Items.Insert(0, SelectText); }
            }
            else if (ctrl.GetType() == typeof(System.Web.UI.WebControls.RadioButtonList))
            {
                RadioButtonList ddls = (RadioButtonList)ctrl;
                ddls.DataSource = dt;
                ddls.DataTextField = DataTextField;
                ddls.DataValueField = DataValueField;
                ddls.DataBind();
            }
            else if (ctrl.GetType() == typeof(System.Web.UI.WebControls.CheckBoxList))
            {
                CheckBoxList ddls = (CheckBoxList)ctrl;
                ddls.DataSource = dt;
                ddls.DataTextField = DataTextField;
                ddls.DataValueField = DataValueField;
                ddls.DataBind();
            }
            else if (ctrl.GetType() == typeof(System.Web.UI.WebControls.ListBox))
            {
                ListBox ddls = (ListBox)ctrl;
                ddls.DataSource = dt;
                ddls.DataTextField = DataTextField;
                ddls.DataValueField = DataValueField;
                ddls.DataBind();
            }
            else if (ctrl.GetType() == typeof(System.Web.UI.WebControls.FormView))
            {
                FormView ddls = (FormView)ctrl;
                ddls.DataSource = dt;
                ddls.DataBind();
            }
            else if (ctrl.GetType() == typeof(System.Web.UI.WebControls.DetailsView))
            {
                DetailsView ddls = (DetailsView)ctrl;
                ddls.DataSource = dt;
                ddls.DataBind();
            }
            else if (ctrl.GetType() == typeof(System.Web.UI.WebControls.GridView))
            {
                GridView ddls = (GridView)ctrl;
                ddls.DataSource = dt;
                ddls.DataBind();
            }
            else if (ctrl.GetType() == typeof(System.Web.UI.WebControls.ListView))
            {
                ListView ddls = (ListView)ctrl;
                ddls.DataSource = dt;
                ddls.DataBind();
            }
        }
        catch (Exception Ex) { }
    }
    #endregion

    #region Other Members
    public static string Numbers2Words(string inputNumber)
    {
        int inputNo = Convert.ToInt32(inputNumber);
        if (inputNo == 0) { return "Zero"; }
        int[] numbers = new int[4];
        int first = 0, u, h, t;
        StringBuilder sb = new StringBuilder();
        if (inputNo < 0) { sb.Append("Minus "); inputNo = -inputNo; }
        string[] words0 = { "", "One ", "Two ", "Three ", "Four ", "Five ", "Six ", "Seven ", "Eight ", "Nine " };
        string[] words1 = { "Ten ", "Eleven ", "Twelve ", "Thirteen ", "Fourteen ", "Fifteen ", "Sixteen ", "Seventeen ", "Eighteen ", "Nineteen " };
        string[] words2 = { "Twenty ", "Thirty ", "Forty ", "Fifty ", "Sixty ", "Seventy ", "Eighty ", "Ninety " };
        string[] words3 = { "Thousand ", "Lakhs ", "Crore " };
        numbers[0] = inputNo % 1000;
        numbers[1] = inputNo / 1000;
        numbers[2] = inputNo / 100000;
        numbers[1] = numbers[1] - 100 * numbers[2];
        numbers[3] = inputNo / 10000000; 
        numbers[2] = numbers[2] - 100 * numbers[3]; 
        for (int i = 3; i > 0; i--) { if (numbers[i] != 0) { first = i; break; } }
        for (int i = first; i >= 0; i--)
        {
            if (numbers[i] == 0) continue;
            u = numbers[i] % 10; 
            t = numbers[i] / 10;
            h = numbers[i] / 100;
            t = t - 10 * h; 
            if (h > 0) sb.Append(words0[h] + "Hundred ");
            if (u > 0 || t > 0)
            {
                if (h > 0 || i == 0) sb.Append("and ");
                if (t == 0) { sb.Append(words0[u]); }
                else if (t == 1) { sb.Append(words1[u]); }
                else { sb.Append(words2[t - 2] + words0[u]); }
            }
            if (i != 0) sb.Append(words3[i - 1]);
        }
        return sb.ToString().TrimEnd();
    }
    public DateTime Server_DateTime(string ConnectionName)
    {
        DateTime dt = new DateTime();
        try
        {
            using (con = new SqlConnection(ConfigurationManager.ConnectionStrings[ConnectionName].ConnectionString))
            {
                if (con.State == ConnectionState.Closed) con.Open();
                cmd.Parameters.Clear();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select DATEADD(MI,tz_diff,GETDATE())[tz_diff] from tbl_TimeZone";
                dt = Convert.ToDateTime(cmd.ExecuteScalar());
            }
        }
        catch (Exception Ex)
        {
            dt = Convert.ToDateTime("1900-01-01");
        }
        finally
        {
            cmd.Dispose();
            if (con.State == ConnectionState.Open) con.Close();
        }
        return dt;
    }
    public string Current_Ident(string ConnectionName,string TableName)
    {
        try
        {
            using (con = new SqlConnection(ConfigurationManager.ConnectionStrings[ConnectionName].ConnectionString))
            {
                if (con.State == ConnectionState.Closed) con.Open();
                cmd.Parameters.Clear();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select IDENT_CURRENT('" + TableName + "')";
                Result = Convert.ToString(cmd.ExecuteScalar());
            }
        }
        catch (Exception Ex)
        {
            Result = Ex.Message;
        }
        finally
        {
            cmd.Dispose();
            if (con.State == ConnectionState.Open) con.Close();
        }
        return Result;
    }
    //public string getJSON(DataTable dt)
    //{
    //    System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
    //    List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
    //    Dictionary<string, object> row;
    //    foreach (DataRow dr in dt.Rows)
    //    {
    //        row = new Dictionary<string, object>();
    //        foreach (DataColumn col in dt.Columns)
    //            row.Add(col.ColumnName, dr[col]);
    //        rows.Add(row);
    //    }
    //    return serializer.Serialize(rows);
    //}
    //protected bool IsWindowsAuthenticate(string domain, string username, string pwd)
    //{
    //    string domainAndUsername = domain + @"\" + username;
    //    DirectoryEntry entry = new DirectoryEntry("LDAP://KONENET.com/DC=KONENET,DC=com", domainAndUsername, pwd);
    //    try
    //    {
    //        Object obj = entry.NativeObject;
    //        DirectorySearcher search = new DirectorySearcher(entry);
    //        SearchResult result = search.FindOne();
    //        if (null == result) { return false; }
    //    }
    //    catch { return false; }
    //    return true;
    //}
    public string tokenno(string ConnectionName)
    {
        string tno = string.Empty;
        try
        {
            string tk = string.Empty;
            tk = SingleData(ConnectionName, "select max(OrderNo) from tbl_order_master");
            DateTime dt = Server_DateTime(ConnectionName);
            if (tk != "")
            {
                if ((dt.Day == Convert.ToInt32(tk.Substring(4, 2)) && dt.Month == Convert.ToInt32(tk.Substring(2, 2))) || (dt.Day != Convert.ToInt32(tk.Substring(4, 2)) && dt.Month == Convert.ToInt32(tk.Substring(2, 2))))
                    tno = "LB" + dt.Month.ToString("00") + dt.Day.ToString("00") + (Convert.ToInt32(tk.Substring(tk.Length - 3, 3)) + 1).ToString("000");
                else
                    tno = "LB" + dt.Month.ToString("00") + dt.Day.ToString("00") + "001";
            }
            else
                tno = "LB" + dt.Month.ToString("00") + dt.Day.ToString("00") + "001";
        }
        catch (Exception Ex)
        {
            tno = Ex.Message;
        }
        return tno;
    }
    public string customerid(string ConnectionName,string Option="TL")
    {
        string tno = string.Empty;
        try
        {
            string tk = string.Empty;
            tk = SingleData(ConnectionName, "select max(slno) from tbl_order_master");
            DateTime dt = Server_DateTime(ConnectionName);
            if (tk != "") { tno = Option + (Convert.ToInt32(tk) + 1).ToString("0000"); }
            else { tno = Option + "0001"; }
        }
        catch (Exception Ex)
        {
            tno = Ex.Message;
        }
        return tno;
    }
    #endregion
}
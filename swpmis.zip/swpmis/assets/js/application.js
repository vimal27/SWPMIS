/*! Application.js
* ================
* Application file for Spider PMIS. This file
* should be included in all pages after all Libraries. It provide all common functionalities to Spider PMIS Tool
* ================
* @Author  SenthiLKumar.P
* @Support <http://www.lapizdigital.com>
* @Email   <software@lapizdigital.com>
* @version 1.0.0
* @license MIT <http://opensource.org/licenses/MIT>
*/
function confirmBox(event,msg) {
   // console.log(event, this);
    event.preventDefault();
    event.stopPropagation();
    var theHREF = $(event.target).parent().attr("href");
    var pop = bootbox.dialog({ message: msg, title: "Delete",onEscape:true,backdrop:true,
        buttons: {
            success: {
                label: "OK", className: "btn-danger",
                callback: function (event) {
                    window.location.href = theHREF;
                }
            },
            main: {
                label: "Cancel", className: "btn-default",
                callback: function () {
                }
            }
        }
    });
    pop.on('shown.bs.modal', function () {
        pop.find(".btn-default:first").focus();
    });
}

function showInfo(msg) {
    var pop = bootbox.dialog({ message: msg, title: "Notification", onEscape: true, backdrop: true,
        buttons: {
            main: {
                label: "OK", className: "btn-primary",
                callback: function () {
                }
            }
        }
    });
    pop.on('shown.bs.modal', function () {
        pop.find(".btn-primary:first").focus();
    });
}
function scrollPluggin() {
    $.fn.scrollTo = function (target, options, callback) {
        if (typeof options == 'function' && arguments.length == 2) { callback = options; options = target; }
        var settings = $.extend({
            scrollTarget: target,
            offsetTop: 50,
            duration: 500,
            easing: 'swing'
        }, options);
        return this.each(function () {
            var scrollPane = $(this);
            var scrollTarget = (typeof settings.scrollTarget == "number") ? settings.scrollTarget : $(settings.scrollTarget);
            var scrollY = (typeof scrollTarget == "number") ? scrollTarget : scrollTarget.offset().top + scrollPane.scrollTop() - parseInt(settings.offsetTop);
            scrollPane.animate({ scrollTop: scrollY }, parseInt(settings.duration), settings.easing, function () {
                if (typeof callback == 'function') { callback.call(this); }
            });
        });
    }

}
function validationMethods() {
    var inputQuantity = [];
    $(".percentageVal").each(function (i) {
        inputQuantity[i] = this.defaultValue;
        $(this).data("idx", i); // save this field's index to access later
    });
    $(".percentageVal").on("keyup", function (e) {
        var $field = $(this),
            val = this.value,
            $thisIndex = parseInt($field.data("idx"), 10); // retrieve the index
        //        window.console && console.log($field.is(":invalid"));
        //  $field.is(":invalid") is for Safari, it must be the last to not error in IE8
        if (this.validity && this.validity.badInput || isNaN(val) || $field.is(":invalid")) {
            this.value = inputQuantity[$thisIndex];
            return;
        }
        if (val.length > Number($field.attr("maxlength"))) {
            val = val.slice(0, 5);
            $field.val(val);
        }
        inputQuantity[$thisIndex] = val;
    });
}
function lock() {
    if (event.keyCode == 9 || event.which == 9) {
        event.returnValue = true;
        return true;
    }
    else {
        event.returnValue = false;
    }

    try {
        event.preventDefault();
    }
    catch (e) { }
}